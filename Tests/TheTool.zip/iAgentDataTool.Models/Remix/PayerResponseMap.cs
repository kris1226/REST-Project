﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iAgentDataTool.Models.Remix
{
    public class PayerResponseMap
    {
        public long PayerResponseId { get; set; }
        public string IPRKey { get; set; }
        public string LookupText { get; set; }
        public string HtmlResponseType { get; set; }
    }
}

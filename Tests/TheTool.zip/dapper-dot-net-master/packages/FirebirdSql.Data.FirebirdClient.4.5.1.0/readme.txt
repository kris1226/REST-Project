README - FirebirdClient ADO.NET 2.0 Data provider for Firebird
==============================================================

This project is supported by:
-----------------------------

	Sean Leyne (Broadview Software)
	SMS-Timing


Developement list
-----------------

You can subscribe to the developement list at:

	http://lists.sourceforge.net/lists/listinfo/firebird-net-provider


You can access to the lastest developement sources through SVN, see:

	https://sourceforge.net/p/firebird/NETProvider/


Reporting Bugs
--------------

Yo can report bugs using two ways:

1. Sending it to the developement list.
2. Thru the Firebird Project tracker (category DNET):


	http://tracker.firebirdsql.org/DNET


